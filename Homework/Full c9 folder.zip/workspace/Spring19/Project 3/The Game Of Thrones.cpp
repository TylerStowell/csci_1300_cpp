// CS1300 Spring 2019
// Author: Tyler Stowell
// Recitation: 201 - Supriya Naidu
// Cloud9 Workspace Editor Link: https://ide.c9.io/stowelltm/csci1300
// Homework - The Game Of Thrones

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

