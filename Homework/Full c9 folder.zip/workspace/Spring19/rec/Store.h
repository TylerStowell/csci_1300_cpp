#include <iostream>
#include <string>
using namespace std;

#ifndef STORE_H
#define STORE_H

class Store
{
public:
    Store();
    store(int c, int sh);
    void setCores(int c);
    void setShield(int shield);
    int getCores();
    int getShields();

private:
    int cores;
    int shields;
    vector <Ship> money;
};

#endif