#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <locale>
#include <fstream>
#include <cstdlib> // sorting
#include "Store.h"
using namespace std;

Store::Store()
{
    cores = 0;
    shields = 0;
}

Store::Store(int c, int sh)
{
    cores = c;
    shields = sh;
}

Store::setCores(int cores)
{
    cores = c;
}

Store::seShield(int shield)
{
    shields = shield;
}

Store::getCores()
{
    return cores;
}

Store::getShields()
{
    return shields;
}