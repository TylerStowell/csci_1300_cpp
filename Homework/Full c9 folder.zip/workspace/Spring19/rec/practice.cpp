#include <iostream>

using namespace std;

void poundsToKilograms(int lb){
    double kg = lb/2.2;
    cout << "The weight of " << lb <<"pounds in kilograms is " << fixed << setpercision(2) << kg;
}

int main(){
    int lbs = 19;
    poundsToKilograms(19);
    return 0
    
}