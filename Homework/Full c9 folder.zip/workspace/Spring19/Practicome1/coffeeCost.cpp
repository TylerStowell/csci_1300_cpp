// CS1300 Spring 2019
// Author: Tyler Stowell
// Recitation: 201 - Supriya Naidu
// Cloud9 Workspace Editor Link: https://ide.c9.io/stowelltm/csci1300
// Homework - Problem # 

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

/*
* Algorithm: 
* 1. 
* 2. 
* 3. 
* Input parameters: ()
* Output (prints to screen): 
* Returns: 
*/

double CoffeeCost(int cups, double cost)
{
    int cup = 0;
    double total = 3;
    for(cup = 0; cup <= cups; cup++)
    {
        if(cup%12 == 0)
            {
                total = total;
            }
        else
        {
            total = total + cost;
            
        }
    }
    return total;
}

int main()
{
    cout << CoffeeCost(12,3);
}