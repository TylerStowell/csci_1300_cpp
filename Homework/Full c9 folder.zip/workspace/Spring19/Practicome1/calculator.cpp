// CS1300 Spring 2019
// Author: Tyler Stowell
// Recitation: 201 - Supriya Naidu
// Cloud9 Workspace Editor Link: https://ide.c9.io/stowelltm/csci1300
// Homework - Problem # 

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

/*
* Algorithm: 
* 1. 
* 2. 
* 3. 
* Input parameters: ()
* Output (prints to screen): 
* Returns: 
*/

int calculator(double num1, double num2, char sign)
{
   switch(sign)
    {
       case '+': cout << num1 << " " << sign << " " << num2 << " " << "=" << " " << num1 + num2;break;
       case '-': cout << num1 << " " << sign << " " << num2 << " " << "=" << " " << num1 - num2;break;
       case '*': cout << num1 << " " << sign << " " << num2 << " " << "=" << " " << num1 * num2;break;
       case '/': cout << num1 << " " << sign << " " << num2 << " " << "=" << " " << fixed << showpoint; cout << setprecision(2); cout << num1 / num2;break;
       default: cout << "Invalid operator!";break;
    }
}

int main(){
    char invalid = '!';
    char plus = '+';
    char minus = '-';
    char mult = '*';
    char divide = '/';
    calculator(2,3, divide);
    //test 1
    //expected output
    //
    
    
    //test 2
    //expected output
    //
    
    
}