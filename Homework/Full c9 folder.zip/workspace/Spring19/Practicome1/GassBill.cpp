// CS1300 Spring 2019
// Author: Tyler Stowell
// Recitation: 201 - Supriya Naidu
// Cloud9 Workspace Editor Link: https://ide.c9.io/stowelltm/csci1300
// Homework - Problem # 

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

/*
* Algorithm: 
* 1. 
* 2. 
* 3. 
* Input parameters: ()
* Output (prints to screen): 
* Returns: 
*/

double GasBill(int units)
{
    double unitsDecimal = double(units);
    double unitsDecimal2 = double(units) - 100;
    double unitsDecimal3 = double(units) - 200;
    double total1 = 0;
    double total2 = 0;
    double total3 = 0;
    double final = 0;
    
    if(unitsDecimal <= 100)
    {
        total1 = unitsDecimal * 1.23;
    }
    if(unitsDecimal > 100 && unitsDecimal <= 200)
    {
        // unitsDecimal2 = unitsDecimal2 -100;
        total2 = unitsDecimal2 * 1.14;
    }
    if(unitsDecimal > 200)
    {
        // unitsDecimal3 = unitsDecimal3 -200;
        total3 = unitsDecimal3 * 1.08;
    }
    else
    {
        cout << "Incorrect input" << endl;
        return 0;
    }
    final = total1 + total2 + total3;
    return final;
}

int main(){
    cout << GasBill(87);
    //test 1
    //expected output
    //
    
    
    //test 2
    //expected output
    //
    
    
}