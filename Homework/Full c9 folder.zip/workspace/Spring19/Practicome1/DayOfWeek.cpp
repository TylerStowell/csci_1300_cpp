// CS1300 Spring 2019
// Author: Tyler Stowell
// Recitation: 201 - Supriya Naidu
// Cloud9 Workspace Editor Link: https://ide.c9.io/stowelltm/csci1300
// Homework - Problem # 

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

/*
* Algorithm: 
* 1. 
* 2. 
* 3. 
* Input parameters: ()
* Output (prints to screen): 
* Returns: 
*/

void DayOfWeek(int day)
{
    switch(day)
    {
        case 1: cout << "MONDAY";break;
        case 2: cout << "WORKDAY";break;
        case 3: cout << "WORKDAY";break;
        case 4: cout << "WORKDAY";break;
        case 5: cout << "FUNDAY";break;
        case 6: cout << "SLEEPDAY";break;
        case 0: cout << "SLEEPDAY";break;
        default: cout << "INVALID";
    }
}

int main(){
    DayOfWeek(4);
    //test 1
    //expected output
    //
    
    
    //test 2
    //expected output
    //
    
    
}