#include <iostream>
#include <iomanip>
#include <string>
#include <algorithm>
#include <locale>
using namespace std;

bool similarity(int arr1[ ], int size1, int arr2[], int size2)
{
    for(int i = 0; i < size1; i++)
    {
        if(arr1[i] == arr2[i])
        {
            return true;
        }
        else
        {
            return false;
        }
}