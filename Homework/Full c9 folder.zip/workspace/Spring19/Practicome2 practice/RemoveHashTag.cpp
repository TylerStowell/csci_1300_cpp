#include <iostream>
#include <iomanip>
#include <string>

string RemoveHashTag(string str)
{
    int size = str.length();
    string str2 = "";
    for(int i = 0; i < size; i++)
    {
        if(str[i] == '#') continue;

        else
        {
            str2 = str2 + str[i];
        }
    }
    return str2;
}
