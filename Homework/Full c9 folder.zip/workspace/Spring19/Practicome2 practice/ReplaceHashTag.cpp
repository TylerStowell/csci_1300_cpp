#include <iostream>
#include <iomanip>
#include <string>

int ReplaceHashTag(string str)
{
    int size = str.length();
    string str2 = "";
    for(int i = 0; i < size; i++)
    {
        if(str[i] == '#')
        {
            str2 = str2 + '@';
        }
        else
        {
            str2 = str2 + str[i];
        }
    }
    cout << str2;
    // return str2;
}
int main()
{
    
    ReplaceHashTag("#Monday #Motivation");
    // cout << ReplaceHashTag("#Monday #Motivation") << endl;
}