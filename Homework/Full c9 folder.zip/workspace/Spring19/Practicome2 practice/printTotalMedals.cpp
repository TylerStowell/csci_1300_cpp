#include <iostream>
#include <iomanip>
#include <string>

int printTotalMedals(string disiplines, int gold[], int silver[], int bronze[], int size)
{
    if(size < 1)
    {
        cout << "Invalid size. Size must be at least 1.";
    }
    else if( size <= 1 && size < size)
    {
        
    }
}
