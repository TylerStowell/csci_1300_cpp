#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

string lowerCase(string str)
{
    // string user = str;
    string str2 = "";
    for(unsigned int i=0;i<str.length();i++) // loops through the string
    {
        str2[i] = tolower(str[i]); // converts uppercase to lowercase letters
    }
    return str2;
}

bool IsAllLower(string str)
{
    // string str2 = "";
    string str2 = lowerCase(str);
    if(str == "")
    {
        return true;
    }
    else if(str == str2)
    {
        return true;
    }
    else
    {
        return false;
    }
}

