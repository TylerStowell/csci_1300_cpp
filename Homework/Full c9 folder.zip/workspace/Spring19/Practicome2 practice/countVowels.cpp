#include <iostream>
#include <iomanip>
#include <string>

int CountVowels(string str)
{
    int vowels = 0;
    int size = str.length();
    if(str == "")
    {
        return -1;
    }
    for(int i = 0; i < size; i++)
    {
        
        if(str[i] == 'a' || str[i] == 'e' || str[i] == 'i' || str[i] == 'o' || str[i] == 'u' || str[i] == 'A' || str[i] == 'E' || str[i] == 'I' || str[i] == 'O' || str[i] == 'U')
        {
            vowels++;
        }
    }
    if(vowels > 0)
    {
        return vowels;
    }
    else
    {
        return 0;
    }
    
}