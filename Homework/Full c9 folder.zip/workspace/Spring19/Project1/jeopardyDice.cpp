// CS1300 Spring 2019
// Author: Tyler Stowell
// Recitation: 201 - Supriya Naidu
// Cloud9 Workspace Editor Link: https://ide.c9.io/stowelltm/csci1300
// Homework - Problem # 3

#include <iostream>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
using namespace std; 

/*
* Algorithm: this program plays a game of jeopardy with dice between a player and the computer.
* 1. check if the players' scores are past 80 to see if the game should end or keep playing
* 2. player 1 plays first. rolling a random die and gets certin points baised off of the number on the die.
* 3. Player 2 (the computer) plays second and does the same as player 1 besides not being asked if it wants to roll or not and keeps playing untill it gets a score above 10.
  4. players keep playing backl and forth untill one player has a score of 80. That player wins the game
* Input parameters: none
* Output (prints to screen): the score from each play and the die value and who wins the game
* Returns: none. Prints to the screen
*/

int player1Total = 0;
int player2Total = 0;

int rollDie()
{
	return random() % 6 + 1; 
}

int player1(int player1Total)
{
    int turnTotal1;
    int roll = rollDie();
    
    switch(roll)
    {
        case 2: turnTotal1 = 0;break;
        case 5: turnTotal1 = 0;break;
        case 4: turnTotal1 == 15;break;
        case 1: turnTotal1 = turnTotal1 + roll;break;
        case 3: turnTotal1 = turnTotal1 + roll;break;
        case 6: turnTotal1 = turnTotal1 + roll;break;
    }
        
    player1Total = player1Total + turnTotal1;
    return player1Total;
}

int player2(int player2Total)
{
    int turnTotal2 = 0;
    while(turnTotal2 <= 10)
        {
            int roll = rollDie();
            if(roll == 2 || roll == 5)
            {
                turnTotal2 = 0;
            }
            else if(roll == 4)
            {
                turnTotal2 == 15;
            }
            else if(roll == 1 || roll == 3 || roll == 6)
            {
                turnTotal2 = turnTotal2 + roll;
            }
        }
    player2Total = player2Total + turnTotal2;
    return player2Total;
}
void end()
{
    cout << "End of game. Thank you for playing" << endl;
}

int choice() // asks the user if they want to roll or hold
{
    char answer;
    cout << "Continue rolling or Hold? (y/n)"; // asks the question
    cin >> answer; // intakes the answer (y/n)
    if(answer == 'y') // checks for yes
    {
       return 1; // returns a number to be used leater
    }
    else if(answer == 'n') // checks for no
    {
        return 0; // returns a number to be used leater
    }
}

void game() // main function that runs the game
{
    int turn;
    while(player1Total <= 80 && player2Total <= 80)// checks to see if the game should keep playing
    {
        turn = choice(); // the player that goes first is the user
        while(turn == 1) // player one's turn
        {
            player1(player1Total); // function call to have the player one get points
            if(player1Total >= 80) // checks to see if player1 has 80 or more points and ends the game
            {
                end(); // function call to end game
            }
            if(turn == 1) // if the turn is still one the loop repeats
            {
                turn = choice(); // asks the user if they want to roll again
            }
            else
            {
                turn = 0; // if the user's turn ended then the computer gets it's turn
            }
        }
        while(turn == 0) // player two playing
        {
            player2(player2Total); // function call to have player two play and get points
            if(player2Total >= 80) // checks to see if player2 has 80 or more points and ends the game
            {
                end(); // function call to end game
            }
            
        }
    }
}


int main()
{
    game(); // starts the game
}