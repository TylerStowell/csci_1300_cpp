// CS1300 Spring 2019
// Author: Tyler Stowell
// Recitation: 201 - Supriya Naidu
// Cloud9 Workspace Editor Link: https://ide.c9.io/stowelltm/csci1300
// Homework - Problem # 3

#include <iostream>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
using namespace std; 

/*
* Algorithm: this program
* 1. 
* 2. 
* 3. 
* Input parameters: ()
* Output (prints to screen): 
* Returns: 
*/

int gameTotal = 80;
int player = 1;
int player1Total = 0;
int player2Total = 0;

int rollDie()
{
	return random() % 6 + 1; 
}

int player1()
{
    int turnTotal1;
    int roll = rollDie();
    if(roll == 2)
    {
        turnTotal1 = 0;
        player = 0;
    }
    else if(roll == 5)
    {
        turnTotal1 = 0;
        player = 0;
    }
    else if(roll == 4)
    {
        turnTotal1 == 15;
        player = 0;
    }
    else if(roll == 1)
    {
        turnTotal1 = turnTotal1 + roll;
    }
    else if(roll == 3)
    {
        turnTotal1 = turnTotal1 + roll;
    }
    else if(roll == 6)
    {
        turnTotal1 = turnTotal1 + roll;
    }
        
    player1Total = player1Total + turnTotal1;
    return player1Total;
}

int player2()
{
    int turnTotal2 = 0;
    while(turnTotal2 <= 10)
        {
            int roll = rollDie();
            if(roll == 2 || roll == 5)
            {
                turnTotal2 = 0;
            }
            else if(roll == 4)
            {
                turnTotal2 == 15;
            }
            else if(roll == 1 || roll == 3 || roll == 6)
            {
                turnTotal2 = turnTotal2 + roll;
            }
        }
    player2Total = player2Total + turnTotal2;
    return player2Total;
}
bool end()
{
    if((player1Total >= gameTotal) || (player2Total >= gameTotal))
    {
        return true;
    }
    else
    {
        return false;
    }
}

int choice()
{
    char answer;
    cout << "Continue rolling or Hold? (y/n)";
    cin >> answer;
    if(answer == 'y')
    {
       return 1
    }
    else if(answer == 'n')
    {
        return 0
    }
    else
    {
        cout << "invalid option";
    }
}

// int player1Roll()
// {
//     int roll1 = rollDie();
//     return rolll;
// }
// int player2Roll()
// {
//     int roll2 = rollDie();
//     return roll2;
// }


void game()
{
    while(!end())
    {
        player = player();
        while(player == 1)
        {
            player1();
        }
        if(player1Total <= 80)
        {
            while(player != 1)
            {
                player2();
            }
        }
    }
}


int main(){
    game();
    //test 1
    //expected output
    //
    
    
    //test 2
    //expected output
    //
    
    
}