// CS1300 Spring 2019
// Author: Tyler Stowell
// Recitation: 201 - Supriya Naidu
// Cloud9 Workspace Editor Link: https://ide.c9.io/stowelltm/csci1300
// HW7


#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "User.h"
#include "User.cpp"
#include "Book.h"
#include "Book.cpp"
using namespace std;



//////////////////////////////////////////////////////////////////////////
// other helper functions... split
int split (string line, char c, string strArray[], int maxStrings)
{
    if (line.length() == 0)
    {
        return 0;
    }
    string word = "";
    int count = 0;
    line = line + c;
    for (int i = 0; i < line.length(); i++)
    {
        if (line[i] == c) 
        {
        	if (word.length() == 0) continue;
            if(count > maxStrings)
            {
                return -1;
            }
            strArray[count] = word;
            count++;
            word = "";
        }
        else
        {
            word = word + line[i];
        }
    }
    return count;
}
//////////////////////////////////////////////////////////////////////////


/* readBooks function
 * the function reads a book file from the text into book and author arrays
 *
 * @param: fileName, string, name of the book file
 * @param: titles, string array, titles of the books are stored
 * @param: authors, string array, authors of the books are stored
 * @param: numBookStored, int, the number of books currently stored in the arrays
 * @param: size, int, the size of the arrays (titles and authors)
 * @return: the number of books read into the array (number of lines in the file)
 *          or appropriate return code
 */

//////////////////////////////////////////////////////////////////////////
// ToDo: implement readBooksfunction

int readBooks(string fileName, Book books[], int numBookStored, int bookArrSize)
{
    ifstream myfile;
    myfile.open(fileName); // open files
    int lineindex = 0;
    int maxStrings = 2;
    int i = numBookStored; // inital number of books in the array
    
    if (myfile.is_open()) // what to do when the file is open
    {
        string line = "";
        
        if(numBookStored == bookArrSize)
        {
            return -2;
        }
        
        while(getline(myfile, line)) // loop throught the lines of the text document
        {
            string strArray[2];
            split(line, ',', strArray, maxStrings); // split the lines by ","
           
           if(line == "")
           {
               continue;
           }
            
           if(i < bookArrSize)
           {
               books[i].setAuthor(strArray[0]); // first split string gets appended to the authors array
               books[i].setTitle(strArray[1]); // rest of the string gets appended to the titles array
               
               
            //   book[i].getAuthor() = strArray[0]; // first split string gets appended to the authors array
            //   book[i].getTitle() = strArray[1]; // rest of the string gets appended to the titles array
                numBookStored++; // books stored gets updated
               i++; // itterator updated
           }
        }
        return i; // number of authors and titles in the arrays
    }
    
    else // what to do if the file doesn't open
    {
        return -1;
    } 
    myfile.close(); // closes the file
}
//////////////////////////////////////////////////////////////////////////


/* readRatings function
 * Read the user ratings from the file and store them
 * into users array and ratings array
 *
 * @param: fileName, string, the name of user rating file
 * @param: users, string array, the array of users
 * @param: ratings, int 2D array, the ratings of each user
 *         row i is user, and column j is a book.
 *         ratings[i][j] is the user_i rated book_j
 * @param: numUsers, int, the number of users currently stored in the array
 * @param: sizeRow, int, the number of rows in the 2D array (capacity)
 * @param: sizeCol, int, the number of column in the 2D array (capacity)
 * @return: the number of users in total or appropriate return code
 */

 //////////////////////////////////////////////////////////////////////////
 // ToDo: implement readRatings function

int readRatings(string fileName, User user[], int numUsersStored, int userArrSize, int maxCol)
{
    ifstream myfile;
    myfile.open(fileName); // open file
    int lineindex = 0;
    int maxStrings = maxCol + 1;
    int i = numUsersStored;
    
    if(numUsersStored >= userArrSize)
    {
        return -2;
    }
    
    if (myfile.is_open())
    {
        string line = "";
        while(getline(myfile, line)) // loop through the lines in the file
        {
            string strArray[maxCol + 1];
            int num = split(line, ',', strArray, maxStrings); // split the lines by the comma
            if(line == "")
            {
                continue;
            }
            
            if(numUsersStored < userArrSize)
            {
                if(line.length() != 0)
                {
                    user[i].setUsername(strArray[0]);
                    for(int j = 0; j < num - 1 ; j++) // loop through the split line
                    {
                        user[j].setRatingAt(i, stoi(strArray[j + 1])); // answer for the index of the rating
                    }
                
                }
                i++;
                numUsersStored++;
            }
        }
        return i; // returns the number of the rating
    }
    else
    {
        return -1;
    } 
    myfile.close();
}
 //////////////////////////////////////////////////////////////////////////

/* printBookList function (helper function)
 * print the list of books in the array
 *
 * @param: titles, string, the title of books
 * @param: authors, string, the author of books
 * @param: numBooks, int, the number of books
 * @return: void
 */


//////////////////////////////////////////////////////////////////////////
// ToDo: implement printAllBooks function

void printAllBooks(Book books[], int numBooks)
{
    int i = 0;
    if(numBooks <= 0) // checks for books
    {
        cout << "No books are stored"; // output if no books present
    }
    else
    {
        cout << "Here is a list of books" << endl; // output before printing books
        
        for(int i = 0; i < numBooks; i++) // loop through the books
        {
            cout << books[i].getTitle() << " by ";
            cout << books[i].getAuthor() << endl; // output for the books and authors on their own lines

        }
    }
}
//////////////////////////////////////////////////////////////////////////

/* getRating function 
 * Search for a rating given the user's name and 
 * book's title and return that value
 *
 * @param: string, username 
 * @param: string, title of the book 
 * @param: string, array, user names
 * @param: string, array, titles
 * @param: 2D int array, list of ratings for each user
 * @param: int, number of users whose names/ratings are currently 
 *         stored in the string array/2D array respectively
 * @param: int, number of books whose titles/ratings are currently 
 *         stored in the string array/2D array respectively
 * @return: int, users's rating value or appropriate return code
 */

//////////////////////////////////////////////////////////////////////////
// ToDo: implement getRating function

string lowerCase(string username)
{
    string user = username;
    for(unsigned int i=0;i<user.length();i++) // loops through the string
    {
        user[i] = tolower(username[i]); // converts uppercase to lowercase letters
    }
    return user;
}

int getRating(string username, string title, User users[], Book books[], int numUsers, int numBooks)
{
    int pos1 = 0;
    int pos2 = 0;
    bool found1;
    bool found2;
    string user = lowerCase(username); // calls function to make the stringall lowercase  

    while(pos1 < numUsers && !found1)  // keeps loop going untill found
    {
        if(lowerCase(users[pos1].getUsername()) == user) // what to do once found
        {
            found1 = true; // bool value if found
        }
        else
        {
            pos1++; // if not found keep looping through each name
        }
    }
    while(pos2 < numBooks && !found2) // same as the first one but with the tiles
    {
        if(lowerCase(books[pos2].getTitle()) == lowerCase(title)) // lowercase letters for titles too
        {
            found2 = true; // bool value if it is in the array
        }
        else
        {
            pos2++; // if not keep going throught the titles untill found
        }
    }

    if((found1 == true) && (found2 == true)) // what to do once you found both the user and the title
    {
        return users[pos1].getRatingAt(pos1); // find the rating for that book by the user
    }
    else
    {
        return -3;
    }
}
//////////////////////////////////////////////////////////////////////////




/* displayMenu:
 * displays a menu with options
 * DO NOT MODIFY THIS FUNCTION
 */
void displayMenu(){
  cout << "Select a numerical option:" << endl;
  cout << "======Main Menu=====" << endl;
  cout << "1. Read book file" << endl;
  cout << "2. Read user file" << endl;
  cout << "3. Print book list" << endl;
  cout << "4. Get rating" << endl;
  cout << "5. Quit" << endl;
}


int main(int argc, char const *argv[]) {

    // taking menu choice 
    string choice;

    // number of books and users stored in the arrays
    int numBooks = 0;
    int numUsers = 0;

    // Use the these values to declare your
    // titles, authors, users and ratings arrays
    const static int  userArrSize = 100;
    const static int  bookArrSize = 50;


    // variables to store user inputs 
    string bookFileName;
    string userFileName;
    string userName, bookTitle;    

    while (choice != "5") {
        displayMenu();

        // take an opton (1, 2, 3, or 4)
        getline(cin, choice);

        // convert the `choice` to an integer 
        int menuChoice = stoi(choice); 
        switch (menuChoice) {
            case 1:
                // read book file
                cout << "Enter a book file name:" << endl;
                getline(cin, bookFileName);

                //////////////////////////////////////////////////////////////////////////
                // Your code here. Call the appropriate function(s).
                //////////////////////////////////////////////////////////////////////////

                // Use the below messages and match them to the return code. Update variables as needed.
                // cout << "No books saved to the database." << endl;
                // cout << "Database is already full. No books were added." << endl;     
                // cout << "Database is full. Some books may have not been added." << endl;     
                // cout << "Total books in the database: " << numBooks << endl;
                
                cout << endl;
                break;

            case 2:
                // read ratings file
                cout << "Enter a user file name:" << endl;
                getline(cin, userFileName);

                //////////////////////////////////////////////////////////////////////////
                // Your code here. Call the appropriate function(s).
                //////////////////////////////////////////////////////////////////////////

                // Use the below messages and match them to the return code. Update variables as needed.
                // cout << "No users saved to the database." << endl;
                // cout << "Database is already full. No users were added." << endl; 
                // cout << "Database is full. Some users may have not been added." << endl; 
                // cout << "Total users in the database: " << numUsers << endl;

                cout << endl;
                break;

            case 3:
                // print the list of the books
                
                //////////////////////////////////////////////////////////////////////////
                // Your code here. Call the appropriate function(s).
                //////////////////////////////////////////////////////////////////////////

                cout << endl;
                break;

            case 4:
                // get user's rating 
                // take user name
                cout << "Enter username:" << endl;
                getline(cin, userName);

                // take book title 
                cout << "Enter book title:" << endl;
                getline(cin, bookTitle);

                //////////////////////////////////////////////////////////////////////////
                // Your code here. Call the appropriate function(s).
                //////////////////////////////////////////////////////////////////////////

                // Use the below messages and match them to the return code. Update variables as needed.
                // cout << userName << " has not rated " << bookTitle << endl; 
                // cout << userName << " or " << bookTitle << " does not exist" << endl; 
                // cout << userName << " rated " << bookTitle << " with " << rate << endl; 


                cout << endl;
                break;
            case 5:
                // quit
                cout << "good bye!" << endl;
                break;

            default:
                cout << "invalid input" << endl;
        }
    }

    return 0;
}