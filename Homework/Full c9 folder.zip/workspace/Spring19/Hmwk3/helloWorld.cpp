// CS1300 Spring 2019
// Author: Tyler Stowell
// Recitation: 201 - Supriya Naidu
// Cloud9 Workspace Editor Link: https://ide.c9.io/stowelltm/csci1300
// Homework 3 - Problem # 1 -- helloWorld

#include <iostream>
using namespace std;

/*
* Algorithm: print Hello World!
* 1. print the statement
* Input parameters: none
* Output (prints to screen): "Hello, World!"
* Returns: 0
*/

// this function is just made in the main function that prints out, "Hello, World!"
int main(){
    cout << "Hello, World!"; // output message
    return 0;
}
