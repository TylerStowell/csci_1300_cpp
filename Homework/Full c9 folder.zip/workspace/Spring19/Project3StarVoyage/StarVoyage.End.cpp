// CS1300 Spring 2019
// Author: Tyler Stowell
// Recitation: 201 - Supriya Naidu
// Cloud9 Workspace Editor Link: https://ide.c9.io/stowelltm/csci1300
// Homework - Project 3 driver

#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <locale>
#include <fstream>
#include <cstdlib> // sorting
#include "Ship.h"
#include "Ships.h"
#include "Ship.cpp"
#include "Ships.cpp"
// #include "Game.h"
// #include "Game.cpp"

using namespace std;

/*
* Algorithm: this game displays a welcome and then a menu. The user can see the instructions and the ships available to play as
//           then the player plays the game with menu option 3. The game asks the player to pick a ship, then shows the ship's
//           stats each turn because they get updated throughout. The player choses to travel, rest, or chargewr chield which affects
//           different aspects of the ship. Every turn, the game checks if the ship is in the same location as an obstacle of an alien.
//           the player has to deside, in both cases, to fight/destroy or to run away. Different strategies can be helpful or devistating.
//           the end goal of this game is to get to the next planet 300 light years away with your ship intact and crew alive.
* 1. show welcome and the menu
* 2. let user choose menu option untill they choose to play the game
* 3. play the game
* Input parameters: none
* Output (prints to screen): the winn or loss of the game
* Returns: 
*/

/* displayMenu:
 * displays a menu with options
 */
 

void printIntro(string fileName) // reads the roster files and puts the names and points of the players into the players vector
{
    ifstream myfile;
    myfile.open(fileName); // opens the file
    int lineindex = 0;
    int maxStrings = 6;
    if (myfile.is_open()) // do things if the file is open
    {
        string line = "";
        while(getline(myfile, line)) // loop throught the lines of the file
        {
            cout << line << endl;
        }
    }
    myfile.close(); // closes file 
}

void readInstructions(string fileName) // reads the roster files and puts the names and points of the players into the players vector
{
    ifstream myfile;
    myfile.open(fileName); // opens the file
    int lineindex = 0;
    int maxStrings = 6;
    if (myfile.is_open()) // do things if the file is open
    {
        string line = "";
        while(getline(myfile, line)) // loop throught the lines of the file
        {
            cout << line << endl;
        }
    }
    myfile.close(); // closes file 
}

void displayMenu() // statring menut to start game or other freatures before beginning the game
{
    cout << endl << endl;
	cout << "Select a numerical option:" << endl;
	cout << "======Main Menu=====" << endl;
	cout << "1. Learn how to play " << endl;
	cout << "2. See the star fleet" << endl;
	cout << "3. Play game" << endl;
	cout << "4. Quit" << endl << endl;
}

void moveMenu() // menue in the game to make turns
{
    cout << endl;
	cout << "Select a numerical option:" << endl;
	cout << "======Menu=====" << endl;
	cout << "1. Travel " << endl;
	cout << "2. rest" << endl;
	cout << "3. charge shield" << endl;
}

void meteorMenu() // menue in the meteor interaction to go around or shoot the meteor
{
	cout << endl;
	cout << "Select a numerical option:" << endl;
	cout << "======Menu=====" << endl;
	cout << "1. Go around " << endl;
	cout << "2. Shoot meteor" << endl << endl;
}

void shipChoice() // statring menut to start game or other freatures before beginning the game
{
    cout << endl;
	cout << "Select a numerical option:" << endl;
	cout << "======Ship Choice=====" << endl;
	cout << "1. Falcon" << endl;
	cout << "2. Zipper" << endl;
	cout << "3. Titan" << endl;
	cout << "4. Quit" << endl << endl;
}


class Alien
{
public:
    Alien();
    Alien(string n, double apos, double st, double cr);
    void setAlienPosition(double apos);
    void setAlienName(string n);
    void setAlienCrew(double cr);
    void setAlienStrength(double st);
    string getAlienName();
    double getAlienCrew();
    double getAlienStrength();
    
private:
    string alienName;
    double alienStrength;
    double alienShieldStrength;
    double alienCrew;
    double alienPosition;
};

Alien::Alien() // default constructor
{
    alienName = "";
    alienStrength = 0;
    alienCrew = 0;
    alienPosition = 0;
}

Alien::Alien(string n, double apos, double st, double cr) // parameterized constructor
{
    alienName = n;
    alienStrength = st;
    alienCrew = cr;
    alienPosition = apos;
}

void Alien::setAlienName(string n) // sets the name
{
    alienName = n;
}

void Alien::setAlienStrength(double st) // sets the strength
{
    alienStrength = st;
}

void Alien::setAlienCrew(double cr) // sets the crew size
{
    alienCrew = cr;
}

void Alien::setAlienPosition(double apos) // sets the position on the path the alien will be
{
    alienPosition = apos;
}

string Alien::getAlienName() // returns the name of the alien
{
    return alienName;
}

double Alien::getAlienStrength() // returns the alien's strenght
{
    return alienStrength;
}

double Alien::getAlienCrew() // returns the size of the crew
{
    return alienCrew;
}

class Aliens
{
public:
    Aliens();
    Aliens(string n);
    int split (string line, char c, string strArray[], int maxStrings);
    void setAliensName(string n);
    void readAliens(string fileName);
    string getAliensName(int i);
    double getAliensPosition(int i);
    double getAliensStrength(int i);
    double getAliensCrew(int i);
    
private:
    string aliensName;
    vector<Alien>aliens;
};

int Aliens::split (string line, char c, string strArray[], int maxStrings) // splits the lines of the text file
    {
        if (line.length() == 0)
        {
            return 0;
        }
        string word = "";
        int count = 0;
        line = line + c;
        for (int i = 0; i < line.length(); i++) // loops through the line
        {
            if (line[i] == c) // checks for the delimiter
            {
            	if (word.length() == 0) continue; // skips enpty lines
                if(count > maxStrings) // if the count is already too big it exits and returns -1
                {
                    return -1;
                }
                strArray[count] = word; // puts the word that was split into a temperary array
                count++; // goes to the next word
                word = ""; // recets the wors for the next array input
            }
            else
            {
                word = word + line[i]; // adds the letters to the word untill it hits the delimiter again
            }
        }
        return count; // the number of words the line was split into
    }

Aliens::Aliens() // default constructor
{
    aliensName = "";
    aliens.clear();
}

Aliens::Aliens(string n) // parameterized constructor
{
    aliensName = n;
    aliens.clear();
}

void Aliens::setAliensName(string n) // sets the name of the single alien from the file
{
    aliensName = n;
}

void Aliens::readAliens(string fileName) // reads the roster files and puts the names and points of the players into the players vector
{
    ifstream myfile;
    myfile.open(fileName); // opens the file
    int lineindex = 0;
    int maxStrings = 3;
    if (myfile.is_open()) // do things if the file is open
    {
        string line = "";
        while(getline(myfile, line)) // loop throught the lines of the file
        {
            string strArray[3];
            split(line, ',', strArray, maxStrings); // splits the name and the points by the comma
            
            Alien alien(strArray[0],stod(strArray[1]),stod(strArray[2])); // sets the name and points of the player from the roster into the player class
            aliens.push_back(alien); // adds the player to the vector of players
        }
    }
    myfile.close(); // closes file 
}


string Aliens::getAliensName(int i) // returns the name of the desired alien
{
    if(i < 0 || i >= aliens.size()) // checks bounds to see if it is a legal call for i
    {
        return "ERROR"; // return value if the value of i is outside of the bounds of the aliens.size()
    }
    else
    {
        return aliens[i].getAlienName(); // returns a string of the alien's name
    }
}

double Aliens::getAliensCrew(int i)
{
    if(i < 0 || i >= aliens.size()) // checks bounds to see if it is a legal call for i
    
    else
    {
        return aliens[i].getAliensPosition(); // returns a string of the position
    }  
}

double Aliens::getAliensStrength(int i)
{
    if(i < 0 || i >= aliens.size()) // checks bounds to see if it is a legal call for i
    {
        return -1; // return value if the value of i is outside of the bounds of the aliens.size()
    }
    else
    {
        return aliens[i].getAlienStrength(); // returns a string of the strength
    }
}

double Aliens::getAliensCrew(int i)
{
    if(i < 0 || i >= aliens.size()) // checks bounds to see if it is a legal call for i
    {
        return -1; // return value if the value of i is outside of the bounds of the aliens.size()
    }
    else
    {
        return aliens[i].getAlienCrew(); // returns a string of the crew size
    }
}

class Obstacle
{
public:
    Obstacle();
    Obstacle(string n, double pos, double s);
    void setMeteorName(string n);
    void setMeteorSize(double s);
    void setMeteorPosition(double pos);
    string getMeteorName();
    double getMeteorSize();
    double getMeteorPosition();
    
private:
    string meteorName;
    double meteorSize;
    double meteorPosition;
    
};

Obstacle::Obstacle // defailt constructor
{
    meteorName = "";
    meteorSize = 0;
    meteorPosition = 0;
}

Obstacle::Obstacle(string n, double pos, double s) // parameterized constructor
{
    meteorName = n;
    meteorPosition = rand() % 300 + 1;
    meteorSize = s;
}

void Obstacle::setMeteorName(string n) // sets the name of the meteor
{
    meteorName = n;
}

void Obstacle::setMeteorSize(double s) // sets the size of the meteor
{
    meteorSize = s;
}

void Obstacle::setMeteorPosition(double pos) // sets the position on the map the meteo can be found
{
    meteorPosition = rand() % 300 + 1;
}

string Obstacle::getMeteorName() // returns the name of the meteor
{
    return meteorName;
}

double Obstacle::getMeteorSize() // returns the size of the meteor
{
    return meteorSize;
}

double Obstacle::getMeteorPosition() // returns the position of the meteor on the map
{
    return meteorPosition;
}

class Obstacles
{
public:
    Obstacles();
    Obstacles(string n);
    int split (string line, char c, string strArray[], int maxStrings);
    void setObstaclesName(string n);
    void readObstacles(string filename);
    string getObstaclesName(int i);
    double getObstaclesPosition(int i);
    double getObstaclesSize(int i);
    
private:
    string obstacleName;
    vector<Obstacle>obstacles;
    
};

Obstacles::Obstacles()
{
    obstacleName = "";
    obstacles.clear();
}

Obstacles::Obstacles(string n)
{
    obstacleName = n;
    obstacles.clear();
}

int Obsticles::split(string line, char c, string strArray[], int maxStrings) // splits the lines of the text file
    {
        if (line.length() == 0)
        {
            return 0;
        }
        string word = "";
        int count = 0;
        line = line + c;
        for (int i = 0; i < line.length(); i++) // loops through the line
        {
            if (line[i] == c) // checks for the delimiter
            {
            	if (word.length() == 0) continue; // skips enpty lines
                if(count > maxStrings) // if the count is already too big it exits and returns -1
                {
                    return -1;
                }
                strArray[count] = word; // puts the word that was split into a temperary array
                count++; // goes to the next word
                word = ""; // recets the wors for the next array input
            }
            else
            {
                word = word + line[i]; // adds the letters to the word untill it hits the delimiter again
            }
        }
        return count; // the number of words the line was split into
    }


void Obstacles::setObstaclesName(string n) // sets the name of the obstacle
{
    obstacleName = n;
}

void Obstacles::readObstacles(string fileName) // reads the roster files and puts the names and points of the players into the players vector
{
    ifstream myfile;
    myfile.open(fileName); // opens the file
    int lineindex = 0;
    int maxStrings = 3;
    if (myfile.is_open()) // do things if the file is open
    {
        string line = "";
        while(getline(myfile, line)) // loop throught the lines of the file
        {
            string strArray[3];
            split(line, ',', strArray, maxStrings); // splits the information by the comma
            
            Obstacle obstacle(strArray[0],stod(strArray[1]),stod(strArray[2])); // sets the data from the file into the obstacles class
            obstacles.push_back(obstacle); // adds the obstavle to the vector of obstacles
        }
    }
    myfile.close(); // closes file 
}

string Obstacles::getObstaclesName(int i) // returns the obstacle's name
{
    if(i < 0 || i >= obstacles.size()) // checks bounds to see if it is a legal call for i
    {
        return "ERROR"; // return value if the value of i is outside of the bounds of the obstacles.size()
    }
    else
    {
        return obstacles[i].getMeteorName(); // returns the obstacle's name as a string 
    }
}

double Obstacles::getObstaclesPosition(int i) // returns the obstacle's position
{
    if(i < 0 || i >= obstacles.size()) // checks bounds to see if it is a legal call for i
    {
        return -1; // return value if the value of i is outside of the bounds of the obstacles.size()
    }
    else
    {
        return obstacles[i].getMeteorPosition(); // returns the obstacle's position
    }
}

double Obstacles::getObstaclesSize(int i) // returns the obstacle's size
{
    if(i < 0 || i >= obstacles.size()) // checks bounds to see if it is a legal call for i
    {
        return -1; // return value if the value of i is outside of the bounds of the obstacles.size()
    }
    else
    {
        return obstacles[i].getMeteorSize(); // returns the obstacle's size
    }
}

class Ship
{
public:
    Ship();
    Ship(string n, double s, double shield, double p, double plaz, double cr);
    void setName(string n);
    void setStrength(double s);
    void setShieldStrength(double st);
    void setPower(double p);
    void setPlazma(double plaz);
    void setCrewSize(double cr);
    string getName();
    double getStrength();
    double getShieldStrength();
    double getPower();
    double getPlazma();
    double getCrewSize();

private:
    string name;
    double strength;
    double shieldStrength;
    double power;
    double plazma;
    double crew;
};

Ship::Ship() // default constructor
{
    name = "";
    strength = 0;
    shieldStrength = 0;
    power = 0;
    plazma = 0;
    crew = 0;
}

Ship::Ship(string n, double s, double shield, double p, double plaz, double cr) // parameterized constructor
{
    name = n;
    strength = s;
    shieldStrength = shield;
    power = p;
    plazma = plaz;
    crew = cr;
}

void Ship::setName(string n) // sets the name of the ship
{
    name = n;
}

void Ship::setStrength(double s) // sets the strength of the ship
{
    strength = s;
}

void Ship::setShieldStrength(double st) // sets the strength of the shield
{
    shieldStrength = st;
}

void Ship::setPower(double p) // sets the power of the ship
{
    power = p;
}

void Ship::setPlazma(double plaz) // sets the plazma of the ship
{
    plazma = plaz;
}

void Ship::setCrewSize(double cr) // sets the crew size
{
    crew = cr;
}

string Ship::getName() // returns the name of the ship
{
    return name;
}

double Ship::getStrength() // returns the strength of the ship
{
    return strength;
}

double Ship::getShieldStrength() // returns the strength of the shield
{
    return shieldStrength;
}

double Ship::getPower() // returns the power of the ship
{
    return power;
}

double Ship::getPlazma() // returns the plazma of the ship
{
    return plazma;
}

double Ship::getCrewSize() // returns the crew size of the ship
{
    return crew;
}

class Ships
{
public:
    Ships();
    Ships(string n);
    int split (string line, char c, string strArray[], int maxStrings);
    void setShipName(string n);
    void readShips(string fileName);
    string getShipName(int i);
    double getShipStrength(int i);
    double getShipShieldStrength(int i);
    double getShipPower(int i);
    double getShipPlazma(int i);
    double getShipCrewSize(int i);
    void display() const;

private:
    string shipName;
    vector<Ship>ships;
};

int Ships::split (string line, char c, string strArray[], int maxStrings) // splits the lines of the text file
    {
        if (line.length() == 0)
        {
            return 0;
        }
        string word = "";
        int count = 0;
        line = line + c;
        for (int i = 0; i < line.length(); i++) // loops through the line
        {
            if (line[i] == c) // checks for the delimiter
            {
            	if (word.length() == 0) continue; // skips enpty lines
                if(count > maxStrings) // if the count is already too big it exits and returns -1
                {
                    return -1;
                }
                strArray[count] = word; // puts the word that was split into a temperary array
                count++; // goes to the next word
                word = ""; // recets the wors for the next array input
            }
            else
            {
                word = word + line[i]; // adds the letters to the word untill it hits the delimiter again
            }
        }
        return count; // the number of words the line was split into
    }

Ships::Ships() // default constructor
{
    shipName = "";
    ships.clear(); // clears the Ships vector
}

Ships::Ships(string n) // parameterized constructor
{
    shipName = n;
    ships.clear();
}

void Ships::setShipName(string n) // sets name
{
    shipName = n;
}

void Ships::readShips(string fileName) // reads the roster files and puts the names and points of the players into the players vector
{
    ifstream myfile;
    myfile.open(fileName); // opens the file
    int lineindex = 0;
    int maxStrings = 6;
    if (myfile.is_open()) // do things if the file is open
    {
        string line = "";
        while(getline(myfile, line)) // loop throught the lines of the file
        {
            string strArray[6];
            split(line, ',', strArray, maxStrings); // splits the data by the comma
            
            Ship ship(strArray[0],stod(strArray[1]),stod(strArray[2]),stod(strArray[3]),stod(strArray[4]),stod(strArray[5])); // sets the name and stats of the ship into the ships class
            ships.push_back(ship); // adds the player to the vector of players
        }
    }
    myfile.close(); // closes file 
}

string Ships::getShipName(int i) // returns the name
{
    if(i < 0 || i >= ships.size()) // checks bounds to see if it is a legal call for i
    {
        return "ERROR"; // return value if the value of i is outside of the bounds of the ships.size()
    }
    else
    {
        return ships[i].getName();  // returns a string of the name
    }
}

double Ships::getShipStrength(int i) // returns the strenght of the ship
{
    if(i < 0 || i >= ships.size()) // checks bounds to see if it is a legal call for i
    {
        return -1; // return value if the value of i is outside of the bounds of the ships.size()
    }
    else
    {
        return ships[i].getStrength(); // returns the strenght of the ship
    }
}

double Ships::getShipShieldStrength(int i) // returns the ship's shield strenght
{
    if(i < 0 || i >= ships.size()) // checks bounds to see if it is a legal call for i
    {
        return -1; // return value if the value of i is outside of the bounds of the ships.size()
    }
    else
    {
        return ships[i].getShieldStrength(); // returns the ship's shield strenght
    }
}

double Ships::getShipPower(int i) // returns the ship's power
{
    if(i < 0 || i >= ships.size()) // checks bounds to see if it is a legal call for i
    {
        return -1; // return value if the value of i is outside of the bounds of the ships.size()
    }
    else
    {
        return ships[i].getPower(); // returns the ship's power
    }
}

double Ships::getShipPlazma(int i) // returns the ship's plazma
{
    if(i < 0 || i >= ships.size()) // checks bounds to see if it is a legal call for i
    {
        return -1; // return value if the value of i is outside of the bounds of the ships.size()
    }
    else
    {
        return ships[i].getPlazma(); // returns the ship's plazma
    }
}

double Ships::getShipCrewSize(int i) // returns the crew size
{
    if(i < 0 || i >= ships.size()) // checks bounds to see if it is a legal call for i
    {
        return -1; // return value if the value of i is outside of the bounds of the ships.size()
    }
    else
    {
        return ships[i].getCrewSize(); // returns the crew size
    }
}

class Game
{
public:
    Game();
    // Game(double p, double power, double cr);
    void shipChoice();
    void moveMenu();
    void meteorMenu();
    void Play();
    void setDistance(double dist);
    void setDistanceLeft(double distl);
    void travel();
    void chargeShield();
    void rest();
    void destroy();
    void battle();
    void setPlasmaCharge(double p);
    void setPowerCore(double power);
    void setCrew(double cr);
    double getDistance();
    double getDistanceLeft();
    double getPlazmaCharge();
    double getPowerCore();
    double getCrewSize();

private:
    double distanceTraveled;
    double distanceLeft;
    // double plasmaCharge;
    // double power;
    // double crew;
    vector <Ships> ship1; // do like the ships class but with the values of the user choice in the (int i) parameter?
    vector<Obstacles> obstacle1;
    vector<Aliens> alien1;
};

Game::Game() // initializes the game with the distance traveled and needed to go
{
    distanceTraveled = 0;
    distanceLeft = 300;
    
}

void Game::shipChoice() // statring menut to start game or other freatures before beginning the game
{
	cout << "Select a numerical option:" << endl;
	cout << "======Ship Choice=====" << endl;
	cout << "1. Falcon" << endl;
	cout << "2. Zipper" << endl;
	cout << "3. Titan" << endl;
	cout << "4. Quit" << endl;
}

void Game::moveMenu() // menue in the game to make turns
{
	cout << "Select a numerical option:" << endl;
	cout << "======Menu=====" << endl;
	cout << "1. Travel " << endl;
	cout << "2. rest" << endl;
	cout << "3. charge shield" << endl;
}

void Game::meteorMenu() // menue in the meteor interaction to go around or shoot the meteor
{
    cout << "What are you going to do? " << endl << endl;
	cout << "Select a numerical option: " << endl;
	cout << "1. Go around " << endl;
	cout << "2. Shoot meteor " << endl;
}


// void Game::Play() // this is the function that does it all. Loads ship and player pics ship. initializes everything, sets up map
// {
//     bool destroyed = false; // initializes the boolean flag to be false so the loop goes at least once
//     int playersShip;
    
//     // initializing the three obstacles positions.
//     Obstacles obstacleA;
//     Obstacles obstacleB;
//     Obstacles obstacleC;

//     // initializing the three aliens positions on the path
//     Aliens alienA;
//     Aliens alienB;
//     Aliens alienC;

//     // this is the path the ship travels on to get to the end planet
//     int trail[300]; // array of numbers 1-300 for the path the ship goes on
//     for(int i = 0; i < 300; i++)// loops throught 300 times to fill in each spot of the aray with the values of 1-300
//     {
//         trail[i] = i + 1;
//     }
    
//     // prompts the user to pick what ship they want to play as
//     string chooseShip;
    
//     shipChoice(); // displays the menue with the ships options
//     getline(cin, chooseShip); // reads the user's input and sets it as the chooseShip variable
//     int shipchoice = stoi(chooseShip); // converts the user's string input to a number to be used in the function call later
    
//     if(shipchoice == 1)
//     {
//         playersShip = 0;
//     }
//     else if(shipchoice == 2)
//     {
//         playersShip = 1;
//     }
//     else if(shipchoice == 3)
//     { 
//         playersShip = 2;
//     }
    
//     // initialize all of the single ship's features from the Ships class. Based off what ship the player chooses
//     string shipName = ship1.getShipName(playersShip);
//     double shipPower = ship1.getShipPower(playersShip);
//     double shipStrength = ship1.getShipStrength(playersShip);
//     double shipShield = ship1.getShipShieldStrength(playersShip);
//     double shipPlazma = ship1.getShipPlazma(playersShip);
//     double shipCrew = ship1.getShipCrewSize(playersShip);

//     while(destroyed == false) // boolean flag to see if the game should continue. When the ship is destroyed, the game ends
//     {
//         // double distanceTraveled = 0;
//         // double distanceLeft = 300;
//         double distanceT = getDistance();
//         double distanceL = getDistanceLeft();
        
//         // each time the player makes a choice and something happens to the ship, good or bad, this prints the stats on the ship to let the layer know what they have
//         cout << "Distance traveled: " << distanceT << " light years" << endl;
//         cout << "Distance to Star Base: " << distanceL << " light years" << endl << endl;
//         cout << "Power: " << shipPower << endl;
//         cout << "Strength: " << shipStrength << endl;
//         cout << "Shield Strength: " << shipShield << endl;
//         cout << "Plazma: " << shipPlazma << endl;
//         cout << "Crew: " << shipCrew << endl << endl << endl;
        
        
//         string playerMove;
//         moveMenu(); // calls the menue function to display the choices
    
//         getline(cin, playerMove); // takes user's input
//         int move = stoi(playerMove); // changes string to integer to be used in the if else statements
        
//         if(move == 1)
//         {
//             travel(); // calls the travel function if the user chooses the first choice, travel
//         }
//         else if(shipchoice == 2)
//         {
//             rest(); // calls the rest function if the user chooses the second choice, rest
//         }
//         else if(shipchoice == 3)
//         {
//             chargeShield(); // calls the chargeShield function if the user chose the third choice, charge shield
//         }
        
//         if(distanceTraveled == obstacleA.getMeteorPosition(0) || distanceTraveled == obstacleB.getMeteorPosition(1) || distanceTraveled == obstacleC.getMeteorPosition(2)) // checks to see if the ship has encountered an obsticle
//         {
//             string meteorChoice;
//             meteorMenu(); // calls the meteorMinue function to display the options the user has on shooting the obstacle or going around.
            
//             getline(cin, meteorChoice);
//             int meteor = stoi(meteorChoice);
            
//             if(meteor == 1)
//             {
//                 destroy(); // calls the function to run if the ship destroys the meteor of if the ship gets destroyed and the game ends in a loss.
//             }
//             else
//             {
//                 setDistanceLeft(getDistanceLeft() + 10); // going around the meteor adds 10 light years to the players path
//             }
            
//         }
        
//         if(distanceTraveled == alienA.getAliensPostition(0) || distanceTraveled == alienB.getAliensPostition(1) || distanceTraveled == alienC.getAliensPostition(2)) // checks to see if the ship has encountered an alien
//           battle(); // calls the function for the ship to battle the alien. The ship wins or gets destroyed and the game ends
//         }
//     }
    
//     if(destroyed == true) // ends game once the bool flag is true
//     {
//         cout << "Your ship has been destroyed. Try again, and this time... don't die."
//     }
    
// }

void Game::setDistance(double dist) // sets the distance traveled by the ship
{
    distanceTraveled = dist;
}

void Game::setDistanceLeft(double distl) // sets the distance left to travel to get to the planet
{
    distanceLeft = distl;
}

void Game::travel() // the ship travels a random distance between 10 and 20 units. didtance left decreases the smae amount and the ships stats are affected
{
    // // distance traveled increases a random number between 10 and 20 light years (the units of travel)
    double const move = rand() % 20 + 10;
    // distanceTraveled = distanceTraveled + move;
    // // distance left decreased by the distance (light years) traveled
    distanceLeft = distanceLeft - move;
    // // power decreases by a random amount between 5 and 20 units
    double shipPower = ship1.getShipPower() - (rand() % 20 + 5);
    // // plazma charge increases ny 2 units
    double shipPlazma = ship1.getShipPlazma() + 2;
    // // crew increases by 4 people
    double shipCrew = ship1.getShipCrewSize() + 4;
    
}

void Game::chargeShield() // ship doesn't move but its shield increases
{
    // distance traveled doesn't move
    // distance left doesn't change
    
    // shield strength increases by 1
    shipShield = shipShield + 1;

}

void Game::rest() // ship doesn't move but its power increases
{
    // distance traveled doesn't move
    // distance left doesn't change
    
    // power increases by 10
    shipPower = shipPower + 10;

}

void Game::destroy() // the ship encounters an obsticle and destroys it or gets destroyed and the game ends
{
    // probobability of destroying the meteor is (1- (meteor size / 100))*(plazma charge / 1000)
    double winning = (1- (meteor size / 100))*(ship strength / 1000);
    if( winning > 0)
    {
        cout << "You have destroyed the meteor! You can now continue on your path." << endl;
        
        // ship's strenght goes down by 5%
        shipStrength = shipStrength * .05;
        
        cout << "Your ship's strength took damage from this interaction. "
    }
    
    // else if the player looses, the ship is destroyed and they have to start again
    else
    {
        destroyed = true;
    }
}

void Game::battle() // the ship encounters an enemy alien and destroys it or gets destroyed and the game ends
{
    // if the player had more crew memebers than the enemy, the player wins and continues on their path
    if(alienA.getAlienCrew() > ship1.getShipCrewSize())
    {
        // the player also gets the enemy's, crew, shield power, and strength
        shieldStrength = shieldStrength + alienA.getAlienStrength;
        shipCrew = shipCrew + alienA.getAlienCrew;
    }
    // if the enemy has more crew members than the player, the enemy wins
    // if the player looses the interaction, the player's ship is destroyed and they have to start again
    else
    {
        destroyed = true;
    }
    
}

double Game::getDistance()
{
    return distanceTraveled;
}

double Game::getDistanceLeft()
{
    return distanceLeft;
}


int main(int argc, char const *argv[])
{
    printIntro("welcomeSign.txt");
    
    string choice;

    while (choice != "4")
    {
        displayMenu();

        // take a menu opton
        getline(cin, choice);

        // convert the choice to an integer
        int menuChoice = stoi(choice);

        // prints the intro stating the instructions on how to play and what the ship's stats mean and affect
        if(menuChoice == 1)
        {
            readInstructions("instructions.txt");
            cout << endl;
            cout << endl;
        }
        
        // shows the user the different ships they can choose from
        // also displays the stats of each ship to help you pick which you may want to use
        else if(menuChoice == 2) // menu oprion to display the directions
        {
            Ships ship1("Falcon");
            ship1.readShips("Ships.txt");
            
            for(int i = 0; i < 3; i++) // loops three times to print the name and stats of all three ships
                {
                    cout << endl << "Ship Name: " << ship1.getShipName(i) << endl; // instead of 0 use the minur choice number - 1 in the parameter
                    cout << "       Strength: " << ship1.getShipStrength(i) << endl;
                    cout << "       Shield Strength: " << ship1.getShipShieldStrength(i) << endl;
                    cout << "       Ship Power: " << ship1.getShipPower(i) << endl;
                    cout << "       Plazma: " << ship1.getShipPlazma(i) << endl;
                    cout << "       Crew Size: " << ship1.getShipCrewSize(i) << endl; 
                }
                cout << endl;
        }
        else if(menuChoice == 3) // menu option to play the game
        {
            // this is the option that actualy plays the game
            // here will have all of the code for playing the game, including the
            // if statements and calls to classes
            
            cout << "choice 3. Game Plays";
            
            bool destroyed = false; // initializes the boolean flag to be false so the loop goes at least once
            int playersShip;
            
            // initializing the three obstacles positions.
            Obstacles obstacleA;
            Obstacles obstacleB;
            Obstacles obstacleC;
        
            // initializing the three aliens positions on the path
            Aliens alienA;
            Aliens alienB;
            Aliens alienC;
        
            // this is the path the ship travels on to get to the end planet
            int trail[300]; // array of numbers 1-300 for the path the ship goes on
            for(int i = 0; i < 300; i++)// loops throught 300 times to fill in each spot of the aray with the values of 1-300
            {
                trail[i] = i + 1;
            }
            
            // prompts the user to pick what ship they want to play as
            string chooseShip;
            
            shipChoice(); // displays the menue with the ships options
            getline(cin, chooseShip); // reads the user's input and sets it as the chooseShip variable
            int shipchoice = stoi(chooseShip); // converts the user's string input to a number to be used in the function call later
            
            if(shipchoice == 1)
            {
                playersShip = 0;
            }
            else if(shipchoice == 2)
            {
                playersShip = 1;
            }
            else if(shipchoice == 3)
            { 
                playersShip = 2;
            }
            
            // initialize all of the single ship's features from the Ships class. Based off what ship the player chooses
            
            // Ships ship2();
            // ship2.readShips("Ships.txt");
            // ship1.setShipName("Falcon");
            
            Ships ship1("Falcon");
            ship1.readShips("Ships.txt");
            ship1.setShipName("Falcon"); // can I use a .get() function here for the minue choice on what ship they want? (minue choice -1 = ship they want)
            // cout << ship1.getShipName(0) << endl; // instead of 0 use the minur choice number - 1 in the parameter
            // cout << ship1.getShipStrength(0) << endl;
            // cout << ship1.getShipShieldStrength(0) << endl;
            // cout << ship1.getShipPower(0) << endl;
            // cout << ship1.getShipPlazma(0) << endl;
            // cout << ship1.getShipCrewSize(0) << endl;
            
            string shipName = ship1.getShipName(playersShip);
            double shipPower = ship1.getShipPower(playersShip);
            double shipStrength = ship1.getShipStrength(playersShip);
            double shipShield = ship1.getShipShieldStrength(playersShip);
            double shipPlazma = ship1.getShipPlazma(playersShip);
            double shipCrew = ship1.getShipCrewSize(playersShip);
            
        
            while(destroyed == false) // boolean flag to see if the game should continue. When the ship is destroyed, the game ends
            {
                while(distanceLeft > 0)
                {
                    
                    double distanceTraveled = 0;
                    double distanceLeft = 300;
                    double distanceT = getDistance();
                    double distanceL = getDistanceLeft();
                    
                    // each time the player makes a choice and something happens to the ship, good or bad, this prints the stats on the ship to let the layer know what they have
                    cout << "Distance traveled: " << distanceT << " light years" << endl;
                    cout << "Distance to Star Base: " << distanceL << " light years" << endl << endl;
                    cout << "Power: " << shipPower << endl;
                    cout << "Strength: " << shipStrength << endl;
                    cout << "Shield Strength: " << shipShield << endl;
                    cout << "Plazma: " << shipPlazma << endl;
                    cout << "Crew: " << shipCrew << endl << endl << endl;
                    
                    
                    string playerMove;
                    moveMenu(); // calls the menue function to display the choices
                
                    getline(cin, playerMove); // takes user's input
                    int move = stoi(playerMove); // changes string to integer to be used in the if else statements
                    
                    if(move == 1)
                    {
                        travel(); // calls the travel function if the user chooses the first choice, travel
                    }
                    else if(shipchoice == 2)
                    {
                        rest(); // calls the rest function if the user chooses the second choice, rest
                    }
                    else if(shipchoice == 3)
                    {
                        chargeShield(); // calls the chargeShield function if the user chose the third choice, charge shield
                    }
                    
                    if(distanceTraveled == obstacleA.getMeteorPosition(0) || distanceTraveled == obstacleB.getMeteorPosition(1) || distanceTraveled == obstacleC.getMeteorPosition(2))
                    {
                        string meteorChoice;
                        meteorMenu(); // calls the meteorMinue function to display the options the user has on shooting the obstacle or going around.
                        
                        getline(cin, meteorChoice);
                        int meteor = stoi(meteorChoice);
                        
                        if(meteor == 1)
                        {
                            destroy(); // calls the function to run if the ship destroys the meteor of if the ship gets destroyed and the game ends in a loss.
                        }
                        else
                        {
                            setDistanceLeft(getDistanceLeft() + 10); // going around the meteor adds 10 light years to the players path
                        }
                        
                    }
                    
                    if(distanceTraveled == alienA.getAliensPostition(0) || distanceTraveled == alienB.getAliensPostition(1) || distanceTraveled == alienC.getAliensPostition(2))
                    {
                      battle(); // calls the function for the ship to battle the alien. The ship wins or gets destroyed and the game ends
                    }
                }
                
                if(destroyed == true) // game ends when destroyed = true
                {
                    cout << "Your ship has been destroyed. Try again, and this time... don't die." << endl;
                }
            }
            
            
        }
        
        else if(menuChoice == 4) // quits the game
        {
            cout << "good bye!" << endl;
        }
        
        else
        {
            // tells the user that the choice they made isn't valid
            // redisplays the menue
            cout << "invalid input" << endl;
        }

    }
}