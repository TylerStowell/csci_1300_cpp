int luminosity(double b, double d){
    int luminosity;
    luminosity = 4 * b * 3.14159 * pow(d,2);
    return luminosity;
    
}