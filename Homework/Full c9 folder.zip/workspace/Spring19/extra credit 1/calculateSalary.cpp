int calculateSalary(int rainy,int cold,int sunny){
    return (5 * rainy + 4 * cold + 8 * sunny) * 10;
}