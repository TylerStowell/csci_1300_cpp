double areaOfCircle(int radius)
{
    double area;
    area = 3.14 * pow(radius,2);
    return area;
}