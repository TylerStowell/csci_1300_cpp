void poundsToKilograms(int lb){
    double kg;
    kg = lb/2.2;
    cout << fixed << showpoint;
    cout << setprecision(2);
    cout << "The weight of " << lb << " pounds in kilograms is " << kg;
}