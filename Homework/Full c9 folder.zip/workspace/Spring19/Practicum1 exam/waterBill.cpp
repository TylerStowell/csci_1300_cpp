#include <iostream>
#include <iomanip>
#include <string>
using namespace std;


double waterBill(int gallonsUsed,int lowUsageLimit)
{
    double totalCost = 0;
    if(gallonsUsed <= lowUsageLimit)
    {
        totalCost = gallonsUsed * 0.012;
    }
    else
    {
        totalCost = gallonsUsed * 0.018;
    }
    return totalCost;
}

int main()
{
   cout << waterBill(3900,4000);
}