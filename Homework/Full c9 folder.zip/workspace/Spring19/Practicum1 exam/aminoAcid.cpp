#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

void aminoAcid(char letter)
{
    switch(letter)
    {
        case 'A': cout << "Amino Acid " << letter << ": " << "Adenine";break;
        case 'C': cout << "Amino Acid " << letter << ": " << "Cytosine";break;
        case 'T': cout << "Amino Acid " << letter << ": " << "Thymine";break;
        case 'G': cout << "Amino Acid " << letter << ": " << "Guanine";break;
        default: cout << "Amino Acid " << letter << ": " << "Invalid";
    }
}

int main()
{
    
}