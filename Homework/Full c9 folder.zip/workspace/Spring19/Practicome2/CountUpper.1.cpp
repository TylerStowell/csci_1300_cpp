#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

string upperCase(string str)
{
    string str2 = "";
    for(unsigned int i=0;i<str.length();i++)
    {
        str2[i] = toupper(str[i]);
    }
    return str2;
}

int CountUpper(string str)
{
    int count = 0;
    int size = str.length();
    // string str2 = upperCase(str);
    for(int i = 0; i < size; i++)
    {
        if(str[i] == 'A' || str[i] == 'B' || str[i] == 'C' || str[i] == 'D' || str[i] == 'E' || str[i] == 'F' || str[i] == 'G' || str[i] == 'H' || str[i] == 'I' || str[i] == 'J' || str[i] == 'K' || str[i] == 'L' || str[i] == 'M' || str[i] == 'N' || str[i] == 'O' || str[i] == 'P' || str[i] == 'Q' || str[i] == 'R' || str[i] == 'S' || str[i] == 'T' || str[i] == 'U' || str[i] == 'V' || str[i] == 'W' || str[i] == 'X' || str[i] == 'Y' || str[i] == 'Z')
        {
            count++;
        }
    }
    
    if(str == "")
    {
        return -1;
    }
    if(count > 0)
    {
        return count;
    }
    else
    {
        return -2;
    }
}



