#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

void printEligibleAthletes(string names[], double age[], int size)
{
    for(int i = 0; i < size; i++)
    {
        if(age[i] >= 14 && age[i] <= 18)
        {
            cout<< names[i] << ", " << age[i]<< endl;
        }
    }
}