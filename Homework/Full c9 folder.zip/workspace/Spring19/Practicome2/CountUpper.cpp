#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

string upperCase(string str)
{
    string str2 = "";
    for(unsigned int i=0;i<str.length();i++)
    {
        str2[i] = toupper(str[i]);
    }
    return str2;
}

int CountUpper(string str)
{
    int count = 0;
    int size = str.length();
    string str2 = upperCase(str);
    if(str == "")
    {
        return -1;
    }
    for(int i = 0; i < size; i++)
    {
        if(str[i] == str2[i])
        {
            count++;
        }
    }
    if(count > 0)
    {
        return count;
    }
    else
    {
        return -2;
    }
    
}



