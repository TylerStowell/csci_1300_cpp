#include <iostream>
#include <iomanip>
#include <string>
#include <ifstream>
#include <setprecision>
using namespace std;

int calcCost(string fileName)
{
    int totalCost = 0.0;
    int cost = 0.0;
    // int getLinesFromFile(string fileName, int arr[], int length)
    ifstream myfile;
    myfile.open(fileName); 
    int lineindex = 0;
    if (myfile.is_open()) 
    {
        string line = "";
        while(getline(myfile, line)) 
        {
            string words[3];
            int maxWords = 4;
            setprecision;
            split(line, ',', words, maxWords);
            if(line != "")
            {
                cost = stod(words[1]) * stod(words[2]);
                cout << words[0] << ": " << setprecision(2) << cost << endl;
                totalCost = totalCost + cost;
                lineindex++;
            }
        }
    }
    
    else
    {
        return -1;
    } 
    cout << "Total: " << totalCost;
    return lineindex;
    myfile.close();
}