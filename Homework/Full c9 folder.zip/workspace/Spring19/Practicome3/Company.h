#ifndef COMPANY_H
#define COMPANY_H

class Company
{
public:
    Company();
    Company(string name);
    bool AddEmployee(string name, int salary);
    double CalcAvgSalaries();
    int getMaxSalary();
    int CountSameNames(string name);


    
private:
    string companyName;
    vector <string> EmployeeNames;
    vector <int> EmployeeSalary;
    
};

#endif
