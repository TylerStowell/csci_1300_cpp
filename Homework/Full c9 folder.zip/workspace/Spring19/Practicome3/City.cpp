#ifndef CITY_H
#define CITY_H

class City
{
public:
    City();
    City(string n, int p);
    void setName(string n);
    void setPopulation(int p);
    string getName();
    int getPopulation();
    string category();


    
private:
    string name;
    int population;
    
};

#endif

City::City()
{
    name = "";
    population = 0;
}

City::City(string n, int p)
{
    name = n;
    population = p;
}

void City::setName(string n);
{
    name = n;
}

void City::setPopulation(int p);
{
    population = p;
}

string City::getName();
{
    return name;
}

int City::getPopulation();
{
    return population;
}

string City::category();
{
    if(population > 0 && population < 2000)
    {
        return "Village";
    }
    if(population > 2001 && population < 10000)
    {
        return "Town";
    }
    if(population > 10001 && population < 50000)
    {
        return "City";
    }
    if(population > 50001 && population < 100000)
    {
        return "Capital";
    }
    if(population > 100001 && population < 500000)
    {
        return "Metropolis";
    }
    if(population > 500001)
    {
        return "Megalopolis";
    }
}

