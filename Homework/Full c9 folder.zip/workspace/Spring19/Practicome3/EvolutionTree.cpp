#ifndef EVOLUTIONTREE_H
#define EVOLUTIONTREE_H

class EvolutionTree
{
public:
    EvolutionTree();
    EvolutionTree(string n, int p);
    int LoadTree(string filename);
    int SearchForSpecies(string speciesName);
    string GetSpecies(int speciesAge);


    
private:
    string species[400];
    int speciesAges[400];
    
};

#endif

EvolutionTree::EvolutionTree()
{
    
    for(int i = 0; i < 400; i++)
    {
        species[i] = "";
    }
    for(int i = 0; i < 400; i++)
    {
        speciesAges[i] = 0;
    }
}

int EvolutionTree::LoadTree(string filename)
{
    ifstream myfile;
    myfile.open(filename);
    int lineindex = 0;
    int maxStrings = 2;
    if (myfile.is_open())
    {
        string line = "";
        while(getline(myfile, line))
        {
            string strArray[2];
            split(line, ',', strArray, maxStrings);
            
            species[lineindex] = strArray[0]; 
            speciesAges[lineindex] = stoi(strArray[1]);
            lineindex++; 
               
        }
        return 0;
    }
    else
    {
        return -1;
    }
    
    myfile.close(); 
}

int EvolutionTree::SearchForSpecies(string speciesName)
{
    int pos1 = 0;
    bool found1;
    while(pos1 < 400 && !found1) 
    {
        if(species[pos1] == speciesName)
        {
            found1 = true;
        }
        else
        {
            pos1++;
        }
    }
    if(found1 == true)
    {
        return pos1;
    }
    else
    {
        return -1;
    }
}

string EvolutionTree::GetSpecies(int speciesAge)
{
    int pos2 = 0;
    bool found2 = false;
    
    while(pos2 < 400 && !found2) 
    {
        if(speciesAges[pos2] == speciesAge)
        {
            found2 = true;
        }
        else
        {
            pos2++;
        }
    }
    if(found2 == true)
    {
        return species[pos2];   
    }
    else
    {
        return "";
    }
}
